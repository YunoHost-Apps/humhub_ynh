<?php
return array (
  '<strong>Login</strong> required' => 'Nepieciešama <strong>autorizācija</strong>',
  'An internal server error occurred.' => 'Notika iekšēja servera kļūda.',
  'You are not allowed to perform this action.' => 'Tev nav tiesību izpildīt šo darbību.',
);
