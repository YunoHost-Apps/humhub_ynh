<?php
return array (
  '<strong>Login</strong> required' => '<strong>Log masuk</strong> diwajibkan',
  'An internal server error occurred.' => 'Satu kesalahan dalaman server berlaku.',
  'You are not allowed to perform this action.' => 'Anda tidak dibenarkan melaksanakan tindakan ini.',
);
