<?php
return array (
  '<strong>Login</strong> required' => 'Es necesario <strong>iniciar sesión</strong>',
  'An internal server error occurred.' => 'Un error interno ha ocurrido',
  'You are not allowed to perform this action.' => 'Usted no tiene permisos para ejecutar esta acción',
);
