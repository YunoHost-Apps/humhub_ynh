<?php
return array (
  'Invalid content id given!' => 'id de contenu non valide',
);
