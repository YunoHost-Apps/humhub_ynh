<?php
return array (
  '<strong>Login</strong> required' => '<strong>Indentification</strong> requise',
  'An internal server error occurred.' => 'Une erreur interne au serveur est survenue.',
  'You are not allowed to perform this action.' => 'Vous n\'êtes pas autorisé à effectuer cette action.',
);