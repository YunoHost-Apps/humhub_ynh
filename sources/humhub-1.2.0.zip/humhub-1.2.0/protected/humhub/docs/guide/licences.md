# Licence

Find more about HumHub Licence here:
https://www.humhub.com/licences


