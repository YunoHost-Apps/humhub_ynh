<?php return array (
  'name' => 'HumHub',
  'language' => 'de',
  'timeZone' => 'Pacific/Niue',
  'components' => 
  array (
    'formatter' => 
    array (
      'defaultTimeZone' => 'Pacific/Niue',
    ),
    'formatterApp' => 
    array (
      'defaultTimeZone' => 'Pacific/Niue',
      'timeZone' => 'Pacific/Niue',
    ),
    'user' => 
    array (
    ),
    'mailer' => 
    array (
      'transport' => 
      array (
      ),
      'useFileTransport' => true,
      'view' => 
      array (
        'theme' => 
        array (
          'name' => 'HumHub',
          'basePath' => 'E:\\codebase\\humhub\\master/themes\\HumHub',
          'publishResources' => false,
        ),
      ),
    ),
    'view' => 
    array (
      'theme' => 
      array (
        'name' => 'HumHub',
        'basePath' => 'E:\\codebase\\humhub\\master/themes\\HumHub',
        'publishResources' => false,
      ),
    ),
  ),
  'params' => 
  array (
    'config_created_at' => 1488377334,
    'horImageScrollOnMobile' => NULL,
  ),
); ?>