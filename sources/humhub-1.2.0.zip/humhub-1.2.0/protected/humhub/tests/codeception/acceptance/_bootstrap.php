<?php
$config = require(dirname(__DIR__) . '/config/acceptance.php');
new humhub\components\Application($config);
