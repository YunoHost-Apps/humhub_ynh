<?php

echo '<h1>ParentView:'.$title.'</h1>';

