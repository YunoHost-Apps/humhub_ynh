<?php

echo '<h1>ParentView2:'.$title.'</h1>';

