<?php

echo '<h1>MailView:'.$title.'</h1>';

