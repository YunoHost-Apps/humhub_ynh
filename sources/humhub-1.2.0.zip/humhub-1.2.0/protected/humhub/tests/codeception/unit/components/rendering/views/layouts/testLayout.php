<?php
echo '<div>TestLayout:'.$content.'</div>';

