<?php

echo '<h1>'.$title.'</h1>';

