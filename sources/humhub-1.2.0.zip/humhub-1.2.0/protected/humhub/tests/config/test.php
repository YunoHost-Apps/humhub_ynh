<?php

return [
    'modules' => ['task'],
    'fixtures' => [
        'default'
    ]
];