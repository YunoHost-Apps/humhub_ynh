<div class="panel panel-default">
    <div class="panel-heading"><?= $title ?></div>
    <div class="panel-body">
        <?= $content ?>
    </div>
</div>
