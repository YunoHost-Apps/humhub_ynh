<div id="status-bar" class="clearfix" style="display:none;">
    <div class="status-bar-body">
        <div class="status-bar-content"></div>
    </div>
</div>