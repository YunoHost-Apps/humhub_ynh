Groups
=======

User groups are used to seperate the responsibility within the system.

TBD


