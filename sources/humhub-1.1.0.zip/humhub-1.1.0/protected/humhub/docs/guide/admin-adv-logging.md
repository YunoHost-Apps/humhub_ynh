Logging
=======

TBD


- [Yii Framework - Logging Documentation](http://www.yiiframework.com/doc-2.0/guide-runtime-logging.html)
- Log Files are stored unter ``protected/runtime/application.log``

## Advanced Logging Targets

You can use different logging targets


### Email Target

TBD

### SyslogTarget

TBD

