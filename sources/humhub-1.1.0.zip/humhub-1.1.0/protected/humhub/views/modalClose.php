<script>
    $('#globalModal').modal('hide');
</script>