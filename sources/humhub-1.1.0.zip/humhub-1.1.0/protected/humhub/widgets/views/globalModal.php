<div class="modal" id="globalModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <?php echo \humhub\widgets\LoaderWidget::widget(); ?>
            </div>
        </div>
    </div>
</div>