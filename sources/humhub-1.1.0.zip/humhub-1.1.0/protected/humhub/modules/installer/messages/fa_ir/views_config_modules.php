<?php
return array (
  'HumHub is very flexible and can be adjusted and/or expanded for various different applications thanks to its’ different modules.  The following modules are just a few examples and the ones we thought are most important for your chosen application.<br><br>You can always install or remove modules later. You can find more available modules after installation in the admin area.' => 'مهيا بسيار نرم و انعطاف پذير است. شما مي توانيد هر لحظه با توجه به نياز خود آن را تغيير دهيد يا مژولي نصب كنيد',
  'Recommended <strong>Modules</strong>' => '
<strong>ماژول هاي پيشنهادي</strong>',
);
