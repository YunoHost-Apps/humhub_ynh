<?php
return array (
  '<strong>Admin</strong> Account' => '<strong>Admin</strong> Konto',
  'You\'re almost done. In this step you have to fill out the form to create an admin account. With this account you can manage the whole network.' => 'Du er næsten færdig. I denne skridt skal du udfylde formularen for at oprette en admin konto. Med denne konto kan du administrere hele netværket.',
);
