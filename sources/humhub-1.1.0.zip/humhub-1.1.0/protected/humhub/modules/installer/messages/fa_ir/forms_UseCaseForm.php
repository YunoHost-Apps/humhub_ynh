<?php
return array (
  'I want to use HumHub for:' => 'چرا مي خواهم از مهيا استفاده كنم؟',
);
