<?php
return array (
  '<strong>Configuration</strong>' => '<strong>پيكربندي</strong>',
  'My club' => 'باشگاه من',
  'My community' => 'شبكه من',
  'My company (Social Intranet / Project management)' => 'شركت من',
  'My educational institution (school, university)' => 'انستيتوي آموزشي من',
  'Skip this step, I want to set up everything manually' => 'مي خواهم همه چيز را خودم نصب كنم',
  'To simplify the configuration, we have predefined setups for the most common use cases with different options for modules and settings. You can adjust them during the next step.' => 'براي سادگي نصب مراحلي چند گانه با توجه به استفاده هاي معمول طراحي شده است',
);
