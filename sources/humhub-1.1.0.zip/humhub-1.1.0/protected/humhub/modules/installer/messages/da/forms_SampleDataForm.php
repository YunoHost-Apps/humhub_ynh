<?php
return array (
  'Set up example content (recommended)' => 'Lav et eksempel indhold (Anbefalet)',
);
