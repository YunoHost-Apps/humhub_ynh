<?php
return array (
  'Name of your network' => 'Navnet på dit netværk',
);
