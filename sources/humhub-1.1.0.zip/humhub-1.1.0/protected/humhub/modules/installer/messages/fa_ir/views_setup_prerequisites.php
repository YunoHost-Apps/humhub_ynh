<?php
return array (
  '<strong>System</strong> Check' => 'بررسی <strong>سیستم</strong>',
  'Check again' => 'بررسی مجدد',
  'Congratulations! Everything is ok and ready to start over!' => 'تبریک! همه چیز مناسب و آماده‌ی شروع است!',
  'Next' => 'بعدی',
  'This overview shows all system requirements of HumHub.' => 'این بررسی اجمالی نمایانگر تمامی نیازهای سیستم هام‌هاب است.',
);
