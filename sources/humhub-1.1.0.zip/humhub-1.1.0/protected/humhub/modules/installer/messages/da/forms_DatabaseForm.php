<?php
return array (
  'Hostname' => 'Vært',
  'Name of Database' => 'Navn på Database',
  'Password' => 'Adgangskode',
  'Username' => 'Brugernavn',
);
