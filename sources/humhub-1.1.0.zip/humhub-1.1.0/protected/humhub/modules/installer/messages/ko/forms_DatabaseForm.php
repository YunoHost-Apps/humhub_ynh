<?php
return array (
  'Hostname' => '',
  'Name of Database' => '',
  'Password' => '',
  'Username' => '',
);
