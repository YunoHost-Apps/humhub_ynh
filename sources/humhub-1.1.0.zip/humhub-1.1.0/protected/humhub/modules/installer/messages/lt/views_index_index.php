<?php
return array (
  '<strong>Welcome</strong> to HumHub<br>Your Social Network Toolbox' => '<strong>Sveiki atvykę </strong> į HumHub<br>Jūsų socialinio tinklo valdymo lauką',
  'Next' => 'Kitas',
  'This wizard will install and configure your own HumHub instance.<br><br>To continue, click Next.' => 'Šis pagalbininkas įdiegs ir nustatys Jūsų asmeninį HumHub. <br><br> Norint tęsti, spauskite čia.',
);
