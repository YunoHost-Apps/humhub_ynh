<?php
return array (
  'Hostname' => '호스트 이름',
  'Name of Database' => '',
  'Password' => '패스워드',
  'Username' => '유저네임',
);
