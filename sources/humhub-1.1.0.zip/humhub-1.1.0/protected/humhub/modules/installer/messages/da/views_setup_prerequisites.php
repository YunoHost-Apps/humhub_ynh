<?php
return array (
  '<strong>System</strong> Check' => '<strong>System</strong> Check',
  'Check again' => 'Check igen',
  'Congratulations! Everything is ok and ready to start over!' => 'Tillykke! Alt ser ud til at være ok og klar til at starte forfra!',
  'Next' => 'Næste',
  'This overview shows all system requirements of HumHub.' => 'Denne oversigt viser alle systemkrav til HumHub.',
);
