<?php
return array (
  'Name of your network' => 'نام شبکه‌ی شما',
);
