<?php
return array (
  'Downloading & Installing Modules...' => 'Downloader og installerer moduler...',
);
