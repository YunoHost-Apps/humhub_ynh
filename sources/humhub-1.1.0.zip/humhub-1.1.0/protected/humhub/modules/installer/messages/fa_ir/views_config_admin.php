<?php
return array (
  '<strong>Admin</strong> Account' => '<strong>حساب ادمين</strong>',
  'You\'re almost done. In this step you have to fill out the form to create an admin account. With this account you can manage the whole network.' => 'تقريبا به اتمام رسيد.....ايجاد كاربري ادمين',
);
