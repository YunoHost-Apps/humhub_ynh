<?php
return array (
  'Hostname' => 'Pagrindinis kompiuteris',
  'Name of Database' => 'Duomenų bazės pavadinimas',
  'Password' => 'Slaptažodis',
  'Username' => 'Vartotojo vardas',
);
