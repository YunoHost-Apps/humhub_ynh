<?php
return array (
  'Hostname' => 'نام میزبان',
  'Name of Database' => 'نام پایگاه‌داده',
  'Password' => 'گذرواژه',
  'Username' => 'نام کاربری',
);
