<?php
return array (
  '<strong>System</strong> Check' => '',
  'Check again' => '',
  'Congratulations! Everything is ok and ready to start over!' => '',
  'Next' => 'Avanti',
  'This overview shows all system requirements of HumHub.' => '',
);
