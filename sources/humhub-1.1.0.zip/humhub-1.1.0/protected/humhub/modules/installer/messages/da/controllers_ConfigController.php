<?php
return array (
  'Calvin Klein – Between love and madness lies obsession.' => 'Calvin Klein – Between love and madness lies obsession.',
  'Create Admin Account' => 'Opret Admin Konto',
  'Nike – Just buy it. ;Wink;' => 'Nike – Just buy it. ;Wink;',
  'We\'re looking for great slogans of famous brands. Maybe you can come up with some samples?' => 'Vi leder efter fede nye slogans til nye kendte mærker. Måske du kan komme med nogle idéer?',
  'Welcome Space' => 'Velkomst Side',
  'Yay! I\'ve just installed HumHub ;Cool;' => 'Yay! Du har lige installeret HumHub ;Cool;',
  'Your first sample space to discover the platform.' => 'Din første prøve side til at udforske platformen.',
);
