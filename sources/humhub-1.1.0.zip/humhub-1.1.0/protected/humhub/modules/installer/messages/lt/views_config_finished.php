<?php
return array (
  '<strong>Congratulations</strong>. You\'re done.' => '<strong>Sveikiname</strong>. Jūs baigėte.',
  'Sign in' => 'Prisiregistruokite',
  'The installation completed successfully! Have fun with your new social network.' => 'Diegimas pavyko sėkmingai! Mėgaukitės savo naujuoju socialiniu tinklu.',
);
