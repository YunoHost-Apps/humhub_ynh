<?php
return array (
  'Hostname' => 'Hostname',
  'Name of Database' => '',
  'Password' => 'Password',
  'Username' => 'Username',
);
