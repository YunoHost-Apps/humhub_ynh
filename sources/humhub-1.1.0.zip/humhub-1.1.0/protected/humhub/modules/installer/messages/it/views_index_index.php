<?php
return array (
  '<strong>Welcome</strong> to HumHub<br>Your Social Network Toolbox' => '',
  'Next' => 'Avanti',
  'This wizard will install and configure your own HumHub instance.<br><br>To continue, click Next.' => '',
);
