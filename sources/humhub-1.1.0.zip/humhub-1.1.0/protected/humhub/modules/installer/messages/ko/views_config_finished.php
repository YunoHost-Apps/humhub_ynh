<?php
return array (
  '<strong>Congratulations</strong>. You\'re done.' => '',
  'Sign in' => '',
  'The installation completed successfully! Have fun with your new social network.' => '',
);
