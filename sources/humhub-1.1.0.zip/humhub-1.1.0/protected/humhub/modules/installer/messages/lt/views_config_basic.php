<?php
return array (
  'Next' => 'Kitas',
  'Of course, your new social network needs a name. Please change the default name with one you like. (For example the name of your company, organization or club)' => 'Be abejo, Jūsų naujam socialiniam tinklui reikia pavadinimo. Prašome pakeisti numatytąjį pavadinimą Jums patinkančiu. (Pavyzdžiui, Jūsų įmonės, organizacijos ar klubo pavadinimas)',
  'Social Network <strong>Name</strong>' => 'Socialinio tinklo strong>Pavadinimas</strong>',
);
