<?php
return array (
  '<strong>Example</strong> contents' => '<strong>Eksempel</strong> indhold',
  'To avoid a blank dashboard after your initial login, HumHub can install example contents for you. Those will give you a nice general view of how HumHub works. You can always delete the individual contents.' => '',
);
