<?php
return array (
  'HumHub is very flexible and can be adjusted and/or expanded for various different applications thanks to its’ different modules.  The following modules are just a few examples and the ones we thought are most important for your chosen application.<br><br>You can always install or remove modules later. You can find more available modules after installation in the admin area.' => 'HumHub er meget fleksibelt og kan blive justeret og/eller udvidet til diverse applikationer takke være de forskellige moduler. De følgende moduler er kun et par eksempler og de vi syntes der er mest vigtig for din valgte applikation.<br><br>Du kan altid installere eller fjerne moduler senere. Du kan finde flere tilgængelige moduler efter installationen i admin området.',
  'Recommended <strong>Modules</strong>' => 'Anbefalede <strong>Modules</strong>',
);
