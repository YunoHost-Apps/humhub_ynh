<?php
return array (
  'Next' => 'بعدی',
  'Of course, your new social network needs a name. Please change the default name with one you like. (For example the name of your company, organization or club)' => 'شبکه‌ی اجتماعی جدید شما به یک نام نیاز دارد. لطفا نام پیش‌فرض را به نامی که خود دوست دارید تغییر دهید. (برای مثال نام شرکت، سازمان و یا کلوب خود)',
  'Social Network <strong>Name</strong>' => '<strong>نام</strong> شبکه‌ی اجتماعی',
);
