<?php
return array (
  '<strong>Database</strong> Configuration' => '',
  'Below you have to enter your database connection details. If you’re not sure about these, please contact your system administrator.' => '',
  'Hostname of your MySQL Database Server (e.g. localhost if MySQL is running on the same machine)' => '',
  'Initializing database...' => '',
  'Next' => 'Avanti',
  'Ohh, something went wrong!' => '',
  'The name of the database you want to run HumHub in.' => '',
  'Your MySQL password.' => '',
  'Your MySQL username' => '',
);
