<?php
return array (
  'Next' => '',
  'Of course, your new social network needs a name. Please change the default name with one you like. (For example the name of your company, organization or club)' => '',
  'Social Network <strong>Name</strong>' => '',
);
