<?php
return array (
  'Allow access for non-registered users to public content (guest access)' => 'اجازه دادن به افراد عضو نشده به مطالب عمومي',
  'Allow friendships between members' => 'اجازه دادن به امكان دوستي بين اعضا',
  'External user can register (The registration form will be displayed at Login))' => 'اعضاي خارج از شبكه هم بتوانند عضو شوند',
  'Newly registered users have to be activated by an admin first' => 'اعضاي جديد بايد توسط مدير تاييد شوند',
  'Registered members can invite new users via email' => 'اعضاي حاضر مي توانند با ايميل ديگران را به سايت دعوت كنند',
);
