<?php
return array (
  'Calvin Klein – Between love and madness lies obsession.' => 'Calvin Klein – Between love and madness lies obsession.',
  'Create Admin Account' => 'ایجاد حساب کاربری مدیر',
  'Nike – Just buy it. ;Wink;' => 'Nike – Just buy it. ;Wink;',
  'We\'re looking for great slogans of famous brands. Maybe you can come up with some samples?' => 'We\'re looking for great slogans of famous brands. Maybe you can come up with some samples?',
  'Welcome Space' => 'انجمن خوشامدگويي',
  'Yay! I\'ve just installed HumHub ;Cool;' => 'بالاخره مهيا نصب شد! هورا',
  'Your first sample space to discover the platform.' => 'اولين انجمني كه شما عضويد',
);
