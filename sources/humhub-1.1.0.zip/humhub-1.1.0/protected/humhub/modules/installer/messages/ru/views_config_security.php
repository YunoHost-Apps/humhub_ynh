<?php
return array (
  'Here you can decide how new, unregistered users can access HumHub.' => 'Здесь вы можете решить, как новые и незарегистрированные пользователи могут получить доступ к HumHub.',
  'Security <strong>Settings</strong>' => '<strong>Настройки</strong> Безопасности',
);
