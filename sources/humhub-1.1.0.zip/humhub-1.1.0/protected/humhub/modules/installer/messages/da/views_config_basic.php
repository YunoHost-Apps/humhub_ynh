<?php
return array (
  'Next' => 'Næste',
  'Of course, your new social network needs a name. Please change the default name with one you like. (For example the name of your company, organization or club)' => 'Selvfølgelig, dit nye sociale netværk skal bruge et navn. Venligst skift dette standard navn med noget du syntes om. (For eksempel navnet på dit firma, organisation eller klub)',
  'Social Network <strong>Name</strong>' => 'Social Netværks <strong>Navn</strong>',
);
