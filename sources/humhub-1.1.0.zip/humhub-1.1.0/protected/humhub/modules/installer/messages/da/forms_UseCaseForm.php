<?php
return array (
  'I want to use HumHub for:' => 'Jeg vil bruge Humhub til:',
);
