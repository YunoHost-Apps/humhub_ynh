<?php
return array (
  '<strong>Database</strong> Configuration' => 'تنظیمات <strong>پایگاه داده</strong>',
  'Below you have to enter your database connection details. If you’re not sure about these, please contact your system administrator.' => 'شما باید در قسمت زیر جزئیات اتصال پایگاه داده‌ی خود را وارد کنید. اگر از این اطلاعات اطمینان ندارید با مدیر سیستم خود تماس بگیرید.',
  'Hostname of your MySQL Database Server (e.g. localhost if MySQL is running on the same machine)' => 'نام میزبانی سرور پایگاه داده‌ی MySQL شما (مثال: اگر MySQL روی دستگاه مشترک در حال اجرا است: localhost)',
  'Initializing database...' => 'در حال مقدار دهي به ديتابيس',
  'Next' => 'بعدی',
  'Ohh, something went wrong!' => 'یک مشکل به وجود آمد!',
  'The name of the database you want to run HumHub in.' => 'نام پایگاه‌داده‌ای که می‌خواهید هام‌هاب را در آن اجرا کنید.',
  'Your MySQL password.' => 'گذرواژه‌ی MySQL شما.',
  'Your MySQL username' => 'نام کاربری MySQL شما.',
);
