<?php
return array (
  'Set up example content (recommended)' => 'اطلاعات پيشفرض بازگرداني شوند',
);
