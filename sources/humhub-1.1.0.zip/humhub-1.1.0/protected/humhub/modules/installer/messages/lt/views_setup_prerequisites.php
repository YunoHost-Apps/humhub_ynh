<?php
return array (
  '<strong>System</strong> Check' => '<strong>Sistemos</strong> patikra',
  'Check again' => 'Patikrinkite dar kartą',
  'Congratulations! Everything is ok and ready to start over!' => 'Sveikiname! Galite pradėti!',
  'Next' => 'Kitas',
  'This overview shows all system requirements of HumHub.' => 'Ši apžvalga rodo visus HumHub sistemos reikalavimus.',
);
