<?php
return array (
  '<strong>Example</strong> contents' => '<strong>مطالب پيشفرض</strong>',
  'To avoid a blank dashboard after your initial login, HumHub can install example contents for you. Those will give you a nice general view of how HumHub works. You can always delete the individual contents.' => 'براي اينكه مهيا خالي نباشد، لطفا مطالب پيشفرض را وارد كنيد',
);
