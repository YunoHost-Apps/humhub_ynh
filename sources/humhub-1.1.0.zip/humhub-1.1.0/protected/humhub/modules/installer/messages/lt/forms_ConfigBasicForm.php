<?php
return array (
  'Name of your network' => 'Jūsų tinklo pavadinimas',
);
