<?php
return array (
  'Here you can decide how new, unregistered users can access HumHub.' => 'اينجا مي توانيد تايين كنيد اعضاي جديد مهيا چگونه مي توانند به آن دسترسي داشته باشند',
  'Security <strong>Settings</strong>' => '<strong>تنظيمات امنيتي</strong>',
);
