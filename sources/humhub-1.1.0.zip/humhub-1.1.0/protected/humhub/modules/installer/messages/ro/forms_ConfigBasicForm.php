<?php
return array (
  'Name of your network' => '',
);
