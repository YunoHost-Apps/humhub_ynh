<?php
return array (
  'Downloading & Installing Modules...' => 'درحال دانلود و نصب ماژول',
);
