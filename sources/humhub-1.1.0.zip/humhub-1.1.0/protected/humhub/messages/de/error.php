<?php
return array (
  '<strong>Login</strong> required' => '<strong>Anmelden</strong> erforderlich',
  'An internal server error occurred.' => 'Es ist ein interner Fehler aufgetreten.',
  'You are not allowed to perform this action.' => 'Du hast keine Berechtigung für diesen Vorgang.',
);
