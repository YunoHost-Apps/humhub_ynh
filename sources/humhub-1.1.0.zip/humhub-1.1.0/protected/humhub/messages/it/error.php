<?php
return array (
  '<strong>Login</strong> required' => '<strong>Login</strong> obbligatorio',
  'An internal server error occurred.' => 'Errore interno del server.',
  'You are not allowed to perform this action.' => 'Non sei abilitato ad effettuare questa operazione.',
);
