<?php
return array (
  '<strong>Login</strong> required' => '<strong>Login</strong> requis',
  'An internal server error occurred.' => 'Une erreur interne est survenue.',
  'You are not allowed to perform this action.' => 'Vous n\'êtes pas autorisé à effectuer cette action.',
);
