<?php
return array (
  '<strong>Login</strong> required' => '<strong>ログイン</strong> 必須',
  'An internal server error occurred.' => '内部サーバー エラーが発生しました。',
  'You are not allowed to perform this action.' => 'この操作を実行することはできません。',
);
