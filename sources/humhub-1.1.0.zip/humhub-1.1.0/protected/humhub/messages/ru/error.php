<?php
return array (
  '<strong>Login</strong> required' => '<strong>требуется</strong> логин',
  'An internal server error occurred.' => 'Произошла внутренняя ошибка сервера.',
  'You are not allowed to perform this action.' => 'Вы не можете выполнить это действие.',
);
