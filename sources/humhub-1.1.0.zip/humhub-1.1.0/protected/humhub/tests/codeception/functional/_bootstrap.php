<?php

$config = require(dirname(__DIR__) . '/config/functional.php');
new humhub\components\Application($config);