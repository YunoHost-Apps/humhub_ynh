<?php

return array(
    array('user_id' => '1', 'module_id' => 'core', 'name' => 'globalSetting', 'value' => 'abc', 'created_at' => NULL, 'created_by' => NULL, 'updated_at' => NULL, 'updated_by' => NULL),
    array('user_id' => '1', 'module_id' => 'someModule', 'name' => 'moduleSetting', 'value' => 'cba', 'created_at' => NULL, 'created_by' => NULL, 'updated_at' => NULL, 'updated_by' => NULL),
    array('user_id' => '2', 'module_id' => 'core', 'name' => 'globalSetting', 'value' => 'xxx', 'created_at' => NULL, 'created_by' => NULL, 'updated_at' => NULL, 'updated_by' => NULL),
    array('user_id' => '2', 'module_id' => 'someModule', 'name' => 'moduleSetting', 'value' => 'yyy', 'created_at' => NULL, 'created_by' => NULL, 'updated_at' => NULL, 'updated_by' => NULL)
);
