<?php

/**
 * HumHub
 * Copyright © 2014 The HumHub Project
 *
 * The texts of the GNU Affero General Public License with an additional
 * permission and of our proprietary license can be found at and
 * in the LICENSE file you have received along with this program.
 *
 * According to our dual licensing model, this program can be used either
 * under the terms of the GNU Affero General Public License, version 3,
 * or under a proprietary license.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 */
return array(
  array('user_id' => '1','firstname' => 'John','lastname' => 'Green','title' => NULL,'gender' => NULL,'street' => NULL,'zip' => NULL,'city' => NULL,'country' => NULL,'state' => NULL,'birthday_hide_year' => NULL,'birthday' => NULL,'about' => NULL,'phone_private' => NULL,'phone_work' => NULL,'mobile' => NULL,'fax' => NULL,'im_skype' => NULL,'im_msn' => NULL,'im_icq' => NULL,'im_xmpp' => NULL,'url' => NULL,'url_facebook' => NULL,'url_linkedin' => NULL,'url_xing' => NULL,'url_youtube' => NULL,'url_vimeo' => NULL,'url_flickr' => NULL,'url_myspace' => NULL,'url_googleplus' => NULL,'url_twitter' => NULL),
  array('user_id' => '2','firstname' => 'Max','lastname' => 'White','title' => NULL,'gender' => NULL,'street' => NULL,'zip' => NULL,'city' => NULL,'country' => NULL,'state' => NULL,'birthday_hide_year' => NULL,'birthday' => NULL,'about' => NULL,'phone_private' => NULL,'phone_work' => NULL,'mobile' => NULL,'fax' => NULL,'im_skype' => NULL,'im_msn' => NULL,'im_icq' => NULL,'im_xmpp' => NULL,'url' => NULL,'url_facebook' => NULL,'url_linkedin' => NULL,'url_xing' => NULL,'url_youtube' => NULL,'url_vimeo' => NULL,'url_flickr' => NULL,'url_myspace' => NULL,'url_googleplus' => NULL,'url_twitter' => NULL),
  array('user_id' => '3','firstname' => 'Sue','lastname' => 'Black','title' => NULL,'gender' => NULL,'street' => NULL,'zip' => NULL,'city' => NULL,'country' => NULL,'state' => NULL,'birthday_hide_year' => '0','birthday' => NULL,'about' => NULL,'phone_private' => NULL,'phone_work' => NULL,'mobile' => NULL,'fax' => NULL,'im_skype' => NULL,'im_msn' => NULL,'im_icq' => NULL,'im_xmpp' => NULL,'url' => NULL,'url_facebook' => NULL,'url_linkedin' => NULL,'url_xing' => NULL,'url_youtube' => NULL,'url_vimeo' => NULL,'url_flickr' => NULL,'url_myspace' => NULL,'url_googleplus' => NULL,'url_twitter' => NULL),
 );
