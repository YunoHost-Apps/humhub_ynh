<?php

/**
 * @link https://www.humhub.org/
 * @copyright Copyright (c) 2015 HumHub GmbH & Co. KG
 * @license https://www.humhub.com/licences
 */

namespace tests\codeception\unit\modules\notification\data;

use humhub\modules\activity\components\BaseActivity;

class TestNotification extends BaseActivity
{

    public $moduleId = "test";
    public $viewName = "asdf";

}
